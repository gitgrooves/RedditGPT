const sentimentAnalyzer = new SentimentAnalyzer();
sentimentAnalyzer.watchUrlChange();